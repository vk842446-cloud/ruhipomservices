<?php
// URL Parameters ko fetch aur sanitize karna
$name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : "Premium Access";
$amt = isset($_GET['amt']) ? htmlspecialchars($_GET['amt']) : "0";
$ver = isset($_GET['v']) ? htmlspecialchars($_GET['v']) : "Full";

// Agar Amount 0 hai toh error se bachne ke liye index par redirect
if ($amt == "0") {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Order - VAULTMAX</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;900&display=swap" rel="stylesheet">
    <style>
        :root { --accent: #8a2be2; --neon: #00f7ff; --bg: #0a0a0c; --surface: #16161a; --success: #00ff95; }
        body { 
            background: var(--bg); 
            color: #fff; 
            font-family: 'Outfit', sans-serif; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            min-height: 100vh; 
            margin: 0; 
            padding: 20px;
        }

        .order-card {
            background: var(--surface);
            width: 100%;
            max-width: 420px;
            padding: 35px;
            border-radius: 35px;
            border: 1px solid rgba(255,255,255,0.05);
            text-align: center;
            box-shadow: 0 25px 60px rgba(0,0,0,0.6);
            position: relative;
            overflow: hidden;
        }

        /* Top Progress Bar */
        .progress {
            height: 4px;
            background: rgba(255,255,255,0.05);
            position: absolute;
            top: 0; left: 0; right: 0;
        }
        .progress-fill {
            width: 66%;
            height: 100%;
            background: linear-gradient(90deg, var(--accent), var(--neon));
        }

        .badge {
            display: inline-block;
            background: rgba(138, 43, 226, 0.1);
            color: var(--accent);
            padding: 6px 15px;
            border-radius: 50px;
            font-size: 11px;
            font-weight: 900;
            letter-spacing: 1px;
            margin-bottom: 15px;
        }

        h2 { margin: 0 0 10px 0; font-size: 1.6rem; font-weight: 900; }
        p.sub { color: #666; font-size: 13px; margin-bottom: 30px; }

        /* Invoice Box */
        .invoice {
            background: rgba(255,255,255,0.02);
            border: 1px dashed #333;
            border-radius: 20px;
            padding: 20px;
            text-align: left;
            margin-bottom: 30px;
        }

        .inv-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            font-size: 14px;
        }
        .inv-label { color: #888; }
        .inv-val { font-weight: 600; color: #eee; }

        .inv-total {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid #222;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .total-label { font-size: 16px; font-weight: 600; }
        .total-amt { font-size: 26px; font-weight: 900; color: var(--success); }

        /* Bottom Section */
        .security {
            font-size: 11px;
            color: #555;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }

        .pay-btn {
            display: block;
            width: 100%;
            background: #fff;
            color: #000;
            padding: 20px;
            border-radius: 18px;
            text-decoration: none;
            font-weight: 900;
            font-size: 16px;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            box-shadow: 0 10px 20px rgba(255,255,255,0.1);
        }
        .pay-btn:hover { transform: translateY(-3px); box-shadow: 0 15px 30px rgba(255,255,255,0.15); }
        .pay-btn:active { transform: scale(0.97); }

        .cancel-link {
            display: inline-block;
            margin-top: 20px;
            color: #444;
            text-decoration: none;
            font-size: 13px;
            transition: 0.2s;
        }
        .cancel-link:hover { color: #888; }
    </style>
</head>
<body>

<div class="order-card">
    <div class="progress"><div class="progress-fill"></div></div>
    
    <span class="badge">SECURE CHECKOUT</span>
    <h2>Order Summary</h2>
    <p class="sub">Review your selection before payment</p>
    
    <div class="invoice">
        <div class="inv-row">
            <span class="inv-label">Pack Name:</span>
            <span class="inv-val"><?php echo $name; ?></span>
        </div>
        <div class="inv-row">
            <span class="inv-label">Access Level:</span>
            <span class="inv-val" style="color:var(--neon)"><?php echo strtoupper($ver); ?> VIP</span>
        </div>
        <div class="inv-row">
            <span class="inv-label">Validity:</span>
            <span class="inv-val">Lifetime Access</span>
        </div>
        <div class="inv-row">
            <span class="inv-label">Delivery:</span>
            <span class="inv-val" style="color:var(--success)">Instant</span>
        </div>
        
        <div class="inv-total">
            <span class="total-label">Payable Amount</span>
            <span class="total-amt">₹<?php echo $amt; ?></span>
        </div>
    </div>

    <div class="security">
        <svg width="14" height="14" fill="currentColor" viewBox="0 0 16 16"><path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2z"/></svg>
        SSL Encrypted Secure Payment
    </div>

    <form action="payment.php" method="POST">
        <input type="hidden" name="amt" value="<?php echo $amt; ?>">
        <input type="hidden" name="item" value="<?php echo $name; ?>">
        <input type="hidden" name="version" value="<?php echo $ver; ?>">
        <button type="submit" class="pay-btn">PROCEED TO PAY ₹<?php echo $amt; ?></button>
    </form>
    
    <a href="index.php" class="cancel-link">← Cancel and Go Back</a>
</div>

</body>
</html>
