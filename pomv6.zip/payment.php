<?php
$amt = isset($_GET['amt']) ? $_GET['amt'] : "99";
$variant = isset($_GET['v']) ? $_GET['v'] : "full";
$pack_name = ($variant == 'half') ? "Half Access" : (($variant == 'big') ? "Ultra Big" : "Full Access");
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Secure Payment | UPI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;900&display=swap" rel="stylesheet">
    <style>
        :root { --pink: #ff0055; --blue: #00f2ff; --bg: #050505; --card: #121212; --green: #00ff88; }
        body { background: var(--bg); color: #fff; font-family: 'Inter', sans-serif; margin: 0; padding: 15px; display: flex; justify-content: center; }
        .pay-wrapper { width: 100%; max-width: 420px; }
        .pay-card { background: var(--card); border-radius: 25px; border: 1px solid #222; padding: 25px 20px; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.6); }

        /* Timer */
        .timer-strip { background: rgba(255,0,85,0.1); color: var(--pink); padding: 8px; border-radius: 10px; font-weight: 900; font-size: 13px; margin-bottom: 20px; border: 1px solid rgba(255,0,85,0.2); }

        .amt-val { font-size: 45px; font-weight: 900; color: var(--green); margin: 10px 0; }
        
        /* QR Section */
        .qr-box { background: #fff; padding: 12px; border-radius: 15px; width: 210px; height: 210px; margin: 0 auto 15px; }
        .qr-box img { width: 100%; height: 100%; border-radius: 5px; }
        
        .dl-btn { display: inline-block; color: var(--blue); text-decoration: none; font-size: 12px; font-weight: 900; margin-bottom: 20px; border: 1px solid var(--blue); padding: 5px 15px; border-radius: 50px; }

        /* UPI Copy Box */
        .upi-copy-container { background: #000; padding: 15px; border-radius: 12px; border: 1px solid #333; margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; }
        .upi-id { font-size: 13px; font-weight: 700; color: #aaa; overflow: hidden; white-space: nowrap; }
        .copy-trigger { color: var(--green); font-weight: 900; font-size: 12px; cursor: pointer; text-transform: uppercase; border: 1px solid var(--green); padding: 4px 8px; border-radius: 5px; }

        /* Input Field */
        .utr-field { width: 100%; padding: 18px; background: #000; border: 1px solid #444; border-radius: 15px; color: #fff; font-size: 16px; font-weight: 900; box-sizing: border-box; outline: none; text-align: center; margin-bottom: 15px; }
        .utr-field:focus { border-color: var(--blue); box-shadow: 0 0 10px rgba(0,242,255,0.2); }

        /* Final Verify Button */
        .verify-now { width: 100%; background: var(--green); color: #000; padding: 18px; border: none; border-radius: 15px; font-size: 15px; font-weight: 900; text-transform: uppercase; cursor: pointer; transition: 0.2s; }
        .verify-now:active { transform: scale(0.96); }
    </style>
</head>
<body>

    <div class="pay-wrapper">
        <div class="pay-card">
            <div class="timer-strip">⏳ SESSION EXPIRES IN: <span id="countdown">05:00</span></div>

            <p style="font-size:11px; font-weight:700; color:#666; margin:0;">TOTAL PAYABLE</p>
            <div class="amt-val">₹<?php echo $amt; ?>.00</div>

            <div class="qr-box">
                <img src="qr.jpg" alt="UPI QR">
            </div>
            
            <a href="qr.jpg" download="Payment_QR.jpg" class="dl-btn">⬇️ DOWNLOAD QR</a>

            <div class="upi-copy-container">
                <span class="upi-id" id="upi-text">bharatpe.8i0l1y1j8n80566@fbpe </span>
                <span class="copy-trigger" onclick="copyUPI()">Copy ID</span>
            </div>

            <input type="number" class="utr-field" id="utr_val" placeholder="ENTER 12 DIGIT UTR NO." oninput="if(this.value.length > 12) this.value = this.value.slice(0, 12);">
            
            <button class="verify-now" onclick="checkPay()">VERIFY & UNLOCK</button>

            <p style="font-size:10px; color:#444; margin-top:15px; font-weight:700;">TRUSTED BY 50K+ PREMIUM USERS</p>
        </div>
    </div>

    <script>
        // Timer Logic
        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);
                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                display.textContent = minutes + ":" + seconds;
                if (--timer < 0) {
                    alert("Session Expired!");
                    window.location.href = "index.php";
                }
            }, 1000);
        }

        window.onload = function () {
            startTimer(300, document.querySelector('#countdown'));
        };

        // Copy UPI Logic
        function copyUPI() {
            var text = document.getElementById("upi-text").innerText;
            navigator.clipboard.writeText(text).then(function() {
                alert("UPI ID Copied to Clipboard!");
            });
        }

        // Final Redirect Logic
        function checkPay() {
            var utr = document.getElementById("utr_val").value;
            if(utr.length < 12) {
                alert("Error: Please enter the 12-digit UTR number correctly.");
            } else {
                // टेलीग्राम पर रीडायरेक्ट
                window.location.href = "https://t.me/ninja8000";
            }
        }
    </script>

</body>
</html>
