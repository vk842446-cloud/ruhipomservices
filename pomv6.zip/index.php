<?php
$logFile = 'stats_data.json';
if (!file_exists($logFile)) {
    die("Error: stats_data.json missing. Open admin.php first.");
}
$data = json_decode(file_get_contents($logFile), true);

if (!isset($data['visits'])) { $data['visits'] = []; }
$data['visits'][] = time();
file_put_contents($logFile, json_encode($data));

$set = $data['settings'];
$tg_user = (!empty($set['tg'])) ? $set['tg'] : "CP_SEELER"; 
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?=$set['store_name']?></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;900&display=swap" rel="stylesheet">
    <style>
        :root { --accent: #8a2be2; --neon: #00f7ff; --bg: #0a0a0c; --surface: #16161a; --success: #00ff95; --gold: #ffcc00; }
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        body { background: var(--bg); color: #e0e0e0; font-family: 'Outfit', sans-serif; margin: 0; padding-bottom: 100px; overflow-x: hidden; }

        header { background: rgba(10, 10, 12, 0.9); backdrop-filter: blur(10px); padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.08); display: flex; justify-content: space-between; align-items: center; position: sticky; top: 0; z-index: 1000; }
        .logo { font-weight: 900; font-size: 1.4rem; color: #fff; }
        .logo span { color: var(--accent); }

        /* Floating Telegram */
        .tg-float { position: fixed; bottom: 85px; right: 20px; width: 55px; height: 55px; background: #229ED9; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(34, 158, 217, 0.4); z-index: 3000; text-decoration: none; animation: bounce 2s infinite; }
        @keyframes bounce { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }

        /* Wallet */
        .premium-box { background: linear-gradient(145deg, #1e1e26, #0a0a0c); margin: 15px; padding: 20px; border-radius: 20px; border: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center; }
        .wallet-pop { animation: wallet-grow 0.5s ease-out; color: var(--success) !important; font-size: 1.8rem !important; }
        @keyframes wallet-grow { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.1); } }

        /* Most Popular Badge */
        .popular-tag { position: absolute; top: 12px; left: 12px; background: var(--gold); color: #000; padding: 5px 12px; border-radius: 8px; font-size: 10px; font-weight: 900; z-index: 20; box-shadow: 0 5px 15px rgba(255, 204, 0, 0.4); border: 1px solid #fff; }

        .big-pack-btn { display: flex; justify-content: space-between; align-items: center; text-decoration: none; background: linear-gradient(90deg, #ff00cc, #3333ff); color: #fff; padding: 22px; border-radius: 20px; font-weight: 900; margin: 15px; border: 1px solid rgba(255,255,255,0.2); animation: pulse-glow 2s infinite; position: relative; }
        @keyframes pulse-glow { 0% { box-shadow: 0 0 5px #ff00cc; } 50% { box-shadow: 0 0 25px #ff00cc; } 100% { box-shadow: 0 0 5px #ff00cc; } }

        /* Post Card */
        .post-card { background: var(--surface); border-radius: 24px; margin: 20px; overflow: hidden; border: 1px solid rgba(255,255,255,0.05); position: relative; }
        .thumb-wrap { width: 100%; position: relative; background: #000; }
        .thumb-wrap img { width: 100%; display: block; filter: brightness(0.9); }
        
        .yt-badge { position: absolute; bottom: 12px; padding: 5px 10px; border-radius: 6px; font-size: 11px; font-weight: 900; color: #fff; background: rgba(0,0,0,0.8); backdrop-filter: blur(5px); z-index: 10; border: 1px solid rgba(255,255,255,0.1); }
        .badge-left { left: 12px; border-bottom: 2px solid var(--neon); }
        .badge-right { right: 12px; border-bottom: 2px solid var(--success); }

        .content-body { padding: 20px; }
        .item-title { font-size: 1.2rem; font-weight: 800; color: #fff; margin-bottom: 18px; line-height: 1.4; }
        
        /* PRICE BUTTONS - FIXED TO SOLID STYLE */
        .action-row { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 15px; }
        .btn-action { text-decoration: none; background: #25252b; color: #fff; text-align: center; padding: 12px; border-radius: 12px; font-size: 11px; font-weight: 700; border: 1px solid #333; }
        
        .buy-row { display: flex; gap: 10px; }
        .buy-btn { flex: 1; text-decoration: none; padding: 16px; border-radius: 16px; text-align: center; font-weight: 900; font-size: 14px; box-shadow: 0 4px 10px rgba(0,0,0,0.3); transition: 0.2s; }
        .buy-btn:active { transform: scale(0.96); }
        
        .btn-lite { background: #1a1a1a; color: var(--accent); border: 2px solid var(--accent); }
        .btn-full { background: #fff; color: #000; border: 2px solid #fff; }

        /* History & Feedback */
        #fake-notify { position: fixed; bottom: 85px; left: 15px; right: 15px; background: #fff; color: #000; padding: 14px; border-radius: 15px; font-size: 12px; display: none; z-index: 5000; font-weight: 700; box-shadow: 0 10px 40px rgba(0,0,0,0.6); animation: slideUp 0.5s; }
        @keyframes slideUp { from { transform: translateY(50px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }

        nav { position: fixed; bottom: 12px; left: 12px; right: 12px; background: rgba(22, 22, 26, 0.95); backdrop-filter: blur(15px); display: flex; justify-content: space-around; padding: 12px; border-radius: 25px; border: 1px solid rgba(255,255,255,0.1); z-index: 2000; }
        .nav-link { color: #666; font-size: 10px; text-decoration: none; text-align: center; font-weight: 700; flex: 1; }
        .nav-link.active { color: var(--neon); }
        .nav-link i { display: block; font-size: 20px; margin-bottom: 4px; font-style: normal; }

        .page-section { display: none; }
        .active-section { display: block; }
        .rev-card { background: #1a1a20; padding: 15px; border-radius: 18px; margin-bottom: 12px; border: 1px solid #222; border-left: 4px solid var(--success); }
    </style>
</head>
<body>

<header>
    <div class="logo">Ruhi<span>mms</span></div>
    <div style="font-size: 10px; color: var(--success); font-weight: 900;">● SECURE PROTOCOL</div>
</header>

<a href="https://t.me/<?=$tg_user?>" class="tg-float" id="tgPop">
    <svg width="28" height="28" viewBox="0 0 24 24" fill="white"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69.01-.03.01-.14-.07-.2-.08-.06-.19-.04-.27-.02-.11.02-1.93 1.23-5.46 3.62-.51.35-.98.52-1.4.51-.46-.01-1.35-.26-2.01-.48-.81-.27-1.45-.42-1.39-.89.03-.24.37-.49 1.02-.74 4-1.74 6.67-2.88 8.01-3.43 3.81-1.58 4.6-1.85 5.12-1.86.11 0 .37.03.54.17.14.12.18.28.2.44-.02.07-.02.13-.03.2z"/></svg>
</a>

<div id="fake-notify"></div>

<div id="home" class="page-section active-section">
    <div class="premium-box">
        <div><small style="color:#888;">MY WALLET</small><br><span id="wallet-amt" style="font-size: 1.6rem; font-weight: 900;">₹0</span></div>
        <div style="text-align:right"><b id="bonus-tag" style="color:#444; font-size:11px;">VERIFYING...</b></div>
    </div>

    <div style="position: relative;">
        <div class="popular-tag">🔥 MOST POPULAR</div>
        <a href="order.php?v=big&amt=<?=$set['p_big']?>&name=<?=urlencode('ULTRA 10-IN-1 BUNDLE')?>" class="big-pack-btn">
            <div><small>LIMITED OFFER</small><br><span style="font-size:1.1rem;">ULTRA BIG BUNDLE</span></div>
            <div style="font-size: 1.6rem;">₹<?=$set['p_big']?></div>
        </a>
    </div>

    <?php foreach($data['posts'] as $i => $p): ?>
    <div class="post-card">
        <?php if($i == 0): ?> <div class="popular-tag">⭐ TRENDING</div> <?php endif; ?>
        
        <div class="thumb-wrap">
            <img src="main<?=($i+1)?>.jpg" onerror="this.src='https://via.placeholder.com/800x450/111/fff?text=Premium+Content+Locked'">
            <div class="yt-badge badge-left">📁 10+ PACKS</div>
            <div class="yt-badge badge-right">👥 18.4K+ BUYERS</div>
        </div>
        <div class="content-body">
            <div class="item-title"><?=$p['t']?></div>
            <div class="action-row">
                <a href="<?=$set['demo']?>" class="btn-action">🎬 WATCH DEMO</a>
                <a href="<?=$set['proof']?>" class="btn-action" style="color:var(--gold); border-color:#444;">📸 PROOFS</a>
            </div>
            <div class="buy-row">
                <a href="order.php?v=half&amt=<?=$p['p1']?>&name=<?=urlencode($p['t'])?>" class="buy-btn btn-lite">₹<?=$p['p1']?></a>
                <a href="order.php?v=full&amt=<?=$p['p2']?>&name=<?=urlencode($p['t'])?>" class="buy-btn btn-full">₹<?=$p['p2']?></a>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<div id="feedback" class="page-section" style="padding:15px;">
    <h3 style="margin-bottom:20px; font-weight:900;">Verified Reviews (32)</h3>
    <div id="rev-list"></div>
</div>

<div id="profile" class="page-section" style="padding:15px;">
    <div class="premium-box" style="background:#111;">
        <div><small>ACCOUNT</small><br><b style="font-size:18px;">#USER_<?=rand(100,999)?></b></div>
        <div style="text-align:right"><b style="color:var(--neon)">PREMIUM</b></div>
    </div>
    <h3 style="margin:20px 0 10px 5px;">Live Dispatch History</h3>
    <div style="background:#16161a; border-radius:20px; padding:10px; border:1px solid #222;">
        <table style="width:100%; border-collapse:collapse; font-size:13px;"><tbody id="h-table"></tbody></table>
    </div>
</div>

<div id="support" class="page-section" style="padding:20px; text-align:center;">
    <div class="post-card" style="padding:50px 15px; margin:0;">
        <h2>Official Support</h2>
        <p style="color:#666;">Contact admin for any payment issues.</p>
        <button onclick="window.location.href='https://t.me/<?=$tg_user?>'" style="background:#229ED9; color:#fff; padding:18px; border-radius:15px; border:none; width:100%; font-weight:900; margin-top:20px;">TELEGRAM ADMIN</button>
    </div>
</div>

<nav>
    <a class="nav-link active" onclick="navTo('home', this)"><i>🏠</i>HOME</a>
    <a class="nav-link" onclick="navTo('feedback', this)"><i>⭐</i>REVIEWS</a>
    <a class="nav-link" onclick="navTo('profile', this)"><i>📜</i>HISTORY</a>
    <a class="nav-link" onclick="navTo('support', this)"><i>💬</i>HELP</a>
</nav>

<script>
    function navTo(id, el) {
        document.querySelectorAll('.page-section').forEach(s => s.classList.remove('active-section'));
        document.getElementById(id).classList.add('active-section');
        document.querySelectorAll('.nav-link').forEach(n => n.classList.remove('active'));
        el.classList.add('active');
        document.getElementById('tgPop').style.display = (id === 'home') ? 'flex' : 'none';
        window.scrollTo(0,0);
    }

    // Wallet Bonus Logic
    setTimeout(() => {
        const wallet = document.getElementById('wallet-amt');
        const tag = document.getElementById('bonus-tag');
        wallet.innerHTML = "₹10";
        wallet.classList.add('wallet-pop');
        tag.innerHTML = "NEW USER BONUS ADDED!";
        tag.style.color = "var(--success)";
    }, 2000);

    // Reviews & History Data
    const reviews = ["Delivery was instant, amazing quality!", "199 wala pack best hai.", "Full HD content, links working fine.", "Genuine seller, thanks admin.", "Highly recommended website.", "Easy to buy and access."];
    reviews.forEach(r => { document.getElementById('rev-list').innerHTML += `<div class="rev-card"><div style="color:var(--gold); font-size:10px; margin-bottom:5px;">★★★★★ VERIFIED</div><div style="font-size:13px;">${r}</div></div>`; });

    const names = ["Aman", "Rahul", "Sam", "Vivek", "Sagar", "Arjun"];
    for(let i=0; i<8; i++) {
        document.getElementById('h-table').innerHTML += `<tr><td style="padding:12px 5px;">${names[i % 6]}****</td><td style="color:var(--success); font-weight:900;">SUCCESS</td><td style="color:#555; text-align:right;">Just now</td></tr>`;
    }

    // Fake Notification Timer
    setInterval(() => {
        const notify = document.getElementById('fake-notify');
        const user = names[Math.floor(Math.random() * names.length)];
        notify.innerHTML = `✅ <b>${user}****</b> just purchased the <b>Ultra Bundle</b>`;
        notify.style.display = 'block';
        setTimeout(() => { notify.style.display = 'none'; }, 4000);
    }, 12000);
</script>
</body>
</html>
