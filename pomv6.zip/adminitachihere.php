<?php
$logFile = 'stats_data.json';

// फाइल चेक करें
if (!file_exists($logFile)) {
    die("Error: stats_data.json नहीं मिली। कृपया पहले index.php खोलें।");
}

$data = json_decode(file_get_contents($logFile), true);

// पासवर्ड मैनेजमेंट
if (!isset($data['settings']['password'])) {
    $data['settings']['password'] = 'ramyt22'; // Default Password
    file_put_contents($logFile, json_encode($data));
}

session_start();

// Logout लॉजिक
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: admin.php");
    exit;
}

// Login लॉजिक
if (isset($_POST['login'])) {
    if ($_POST['pass'] === $data['settings']['password']) {
        $_SESSION['admin_auth'] = true;
    } else {
        $error = "❌ WRONG PASSWORD!";
    }
}

// डेटा अपडेट लॉजिक
if (isset($_SESSION['admin_auth']) && isset($_POST['save_all'])) {
    $data['settings']['p_big'] = $_POST['p_big'];
    $data['settings']['tg'] = $_POST['tg'];
    $data['settings']['demo'] = $_POST['demo'];
    $data['settings']['proof'] = $_POST['proof'];
    
    if (!empty($_POST['new_pass'])) {
        $data['settings']['password'] = $_POST['new_pass'];
    }

    for ($i = 0; $i < 10; $i++) {
        $data['posts'][$i]['t'] = $_POST['title_'.$i];
        $data['posts'][$i]['d'] = $_POST['desc_'.$i];
        $data['posts'][$i]['p1'] = $_POST['p1_'.$i]; 
        $data['posts'][$i]['p2'] = $_POST['p2_'.$i]; 
    }

    file_put_contents($logFile, json_encode($data));
    $status = "🎉 STORE DATA UPDATED SUCCESSFULLY!";
}

if (!isset($_SESSION['admin_auth'])): ?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VaultMax | Admin Login</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;900&display=swap" rel="stylesheet">
    <style>
        body { background: #0a0a0c; color: #fff; font-family: 'Outfit', sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; overflow: hidden; }
        .login-card { background: linear-gradient(145deg, #16161a, #0a0a0c); padding: 40px 30px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.05); width: 90%; max-width: 380px; text-align: center; box-shadow: 0 20px 50px rgba(0,0,0,0.5); position: relative; }
        .login-card::before { content: ''; position: absolute; top: -2px; left: -2px; right: -2px; bottom: -2px; background: linear-gradient(45deg, #ff0055, #8a2be2); border-radius: 32px; z-index: -1; opacity: 0.3; }
        h2 { font-weight: 900; letter-spacing: 2px; margin-bottom: 30px; color: #fff; }
        input { width: 100%; padding: 15px; margin: 15px 0; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); color: #fff; border-radius: 15px; box-sizing: border-box; text-align: center; font-size: 16px; outline: none; transition: 0.3s; }
        input:focus { border-color: #ff0055; background: rgba(255,255,255,0.07); }
        button { background: linear-gradient(90deg, #ff0055, #8a2be2); color: #fff; border: none; padding: 15px 40px; border-radius: 15px; font-weight: 900; cursor: pointer; width: 100%; margin-top: 10px; box-shadow: 0 10px 20px rgba(255, 0, 85, 0.3); }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>VAULT<span style="color:#ff0055;">MAX</span></h2>
        <?php if(isset($error)) echo "<p style='color:#ff4444; font-size:12px; font-weight:900;'>$error</p>"; ?>
        <form method="POST">
            <input type="password" name="pass" placeholder="••••••••" required>
            <button type="submit" name="login">UNLOCK PANEL</button>
        </form>
    </div>
</body>
</html>
<?php exit; endif; ?>

<?php
function get_time_ago($timestamp) {
    $diff = time() - $timestamp;
    if ($diff < 60) return $diff . " sec ago";
    if ($diff < 3600) return round($diff / 60) . " min ago";
    return round($diff / 3600) . " hrs ago";
}
$total_visits = count($data['visits']);
$recent_visitors = array_reverse(array_slice($data['visits'], -5));
?>
<!DOCTYPE html>
<html lang="hi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saini Control Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;900&display=swap" rel="stylesheet">
    <style>
        :root { --accent: #ff0055; --neon: #00f2ff; --bg: #0a0a0c; --card: #16161a; --success: #00ff88; }
        * { box-sizing: border-box; }
        body { background: var(--bg); color: #e0e0e0; font-family: 'Outfit', sans-serif; margin: 0; padding: 0; }
        
        .header-bar { background: rgba(18, 18, 22, 0.95); backdrop-filter: blur(10px); padding: 20px; position: sticky; top: 0; z-index: 1000; border-bottom: 1px solid rgba(255,255,255,0.05); display: flex; justify-content: space-between; align-items: center; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; padding-bottom: 120px; }
        
        .stats-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 30px; }
        .stat-card { background: linear-gradient(145deg, #1e1e24, #16161a); border: 1px solid rgba(255,255,255,0.03); padding: 25px; border-radius: 24px; text-align: center; }
        .stat-card h2 { font-size: 36px; margin: 0; color: #fff; font-weight: 900; }
        .stat-card p { font-size: 11px; color: #666; font-weight: 900; margin-top: 5px; letter-spacing: 1px; }

        .log-box { background: #000; border: 1px solid rgba(0, 242, 255, 0.2); padding: 20px; border-radius: 20px; margin-bottom: 30px; position: relative; overflow: hidden; }
        .log-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #111; font-size: 13px; font-weight: 600; }
        
        .section-header { font-size: 12px; color: var(--accent); font-weight: 900; margin: 40px 0 15px 5px; letter-spacing: 2px; display: flex; align-items: center; }
        .section-header::after { content: ''; height: 1px; flex: 1; background: rgba(255,0,85,0.2); margin-left: 15px; }

        .form-card { background: var(--card); border-radius: 28px; padding: 25px; margin-bottom: 20px; border: 1px solid rgba(255,255,255,0.03); box-shadow: 0 10px 30px rgba(0,0,0,0.2); }
        label { display: block; font-size: 11px; color: #888; font-weight: 800; margin-bottom: 8px; margin-left: 5px; }
        input, textarea { width: 100%; padding: 15px; background: #0d0d0f; border: 1px solid #222; color: #fff; border-radius: 16px; font-weight: 600; margin-bottom: 20px; outline: none; transition: 0.3s; }
        input:focus { border-color: var(--neon); background: #111; }

        .item-badge { background: var(--neon); color: #000; padding: 4px 12px; border-radius: 8px; font-size: 10px; font-weight: 900; margin-bottom: 15px; display: inline-block; }

        .btn-update { position: fixed; bottom: 25px; left: 50%; transform: translateX(-50%); width: 90%; max-width: 500px; background: linear-gradient(90deg, #ff0055, #8a2be2); color: #fff; padding: 20px; border: none; border-radius: 20px; font-weight: 900; font-size: 16px; cursor: pointer; box-shadow: 0 15px 40px rgba(255, 0, 85, 0.4); z-index: 1000; transition: 0.3s; }
        .btn-update:active { transform: translateX(-50%) scale(0.95); }

        .status-msg { background: var(--success); color: #000; padding: 15px; border-radius: 15px; text-align: center; font-weight: 900; margin-bottom: 25px; animation: slideDown 0.5s ease-out; }
        @keyframes slideDown { from { transform: translateY(-20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        
        .logout-btn { background: rgba(255,255,255,0.05); color: #fff; text-decoration: none; padding: 8px 15px; border-radius: 10px; font-size: 11px; font-weight: 900; border: 1px solid rgba(255,255,255,0.1); }
    </style>
</head>
<body>

<div class="header-bar">
    <div style="font-weight:900; font-size:1.2rem;">@NINJA8000<span style="color:var(--accent);">CONTROL</span></div>
    <a href="?logout=1" class="logout-btn">SECURE EXIT</a>
</div>

<div class="container">
    <?php if(isset($status)): ?>
        <div class="status-msg"><?php echo $status; ?></div>
    <?php endif; ?>

    <div class="stats-row">
        <div class="stat-card">
            <p>VISITORS</p>
            <h2><?php echo $total_visits; ?></h2>
        </div>
        <div class="stat-card">
            <p>SYSTEM</p>
            <h2 style="color:var(--neon);">LIVE</h2>
        </div>
    </div>

    <div class="log-box">
        <div style="font-size:10px; font-weight:900; color:var(--neon); margin-bottom:15px; letter-spacing:1px;">ACCESS_LOGS.EXE</div>
        <?php foreach($recent_visitors as $index => $time): ?>
            <div class="log-row">
                <span style="color:#555;"># IP_USER_<?php echo ($total_visits - $index); ?></span>
                <span style="color:var(--success);"><?php echo get_time_ago($time); ?></span>
            </div>
        <?php endforeach; ?>
    </div>

    <form method="POST">
        <div class="section-header">SECURITY GATEWAY</div>
        <div class="form-card">
            <label>Update Panel Password</label>
            <input type="text" name="new_pass" placeholder="Enter new password to change...">
        </div>

        <div class="section-header">GLOBAL STORE SETTINGS</div>
        <div class="form-card">
            <label>Admin Telegram (without @)</label>
            <input type="text" name="tg" value="<?php echo $data['settings']['tg']; ?>">
            
            <label>Ultra Big Bundle Price (₹)</label>
            <input type="number" name="p_big" value="<?php echo $data['settings']['p_big']; ?>">
            
            <label>Preview Video Link</label>
            <input type="text" name="demo" value="<?php echo $data['settings']['demo']; ?>">
            
            <label>Proof Channel Link</label>
            <input type="text" name="proof" value="<?php echo $data['settings']['proof']; ?>">
        </div>

        <div class="section-header">POST MANAGEMENT (10 ITEMS)</div>
        <?php foreach($data['posts'] as $i => $p): ?>
            <div class="form-card">
                <div class="item-badge">DATA SLOT #<?php echo $i+1; ?></div>
                
                <label>Post Title</label>
                <input type="text" name="title_<?php echo $i; ?>" value="<?php echo $p['t']; ?>">
                
                <label>Description / Metadata</label>
                <textarea name="desc_<?php echo $i; ?>" rows="2"><?php echo $p['d']; ?></textarea>
                
                <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
                    <div>
                        <label>Basic Price (₹)</label>
                        <input type="number" name="p1_<?php echo $i; ?>" value="<?php echo $p['p1']; ?>">
                    </div>
                    <div>
                        <label>Premium Price (₹)</label>
                        <input type="number" name="p2_<?php echo $i; ?>" value="<?php echo $p['p2']; ?>">
                    </div>
                </div>
            </div>
        <?php endforeach; ?>

        <button type="submit" name="save_all" class="btn-update">DEPLOY UPDATES TO STORE</button>
    </form>
</div>

</body>
</html>
