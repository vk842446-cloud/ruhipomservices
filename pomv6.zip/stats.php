<?php
$logFile = 'stats_data.json';
// Data load aur error handling
if (!file_exists($logFile)) {
    file_put_contents($logFile, json_encode(["visits" => [], "payments" => []]));
}
$data = json_decode(file_get_contents($logFile), true);

$totalVisits = count($data['visits']);
$totalPayments = count($data['payments']);

// Helper function for Mobile Time
function time_ago($timestamp) {
    $diff = time() - $timestamp;
    if ($diff < 60) return $diff . "s ago";
    if ($diff < 3600) return round($diff / 60) . "m ago";
    if ($diff < 86400) return round($diff / 3600) . "h ago";
    return date("d M", $timestamp);
}

// Stats logic
$dailyVisits = count(array_filter($data['visits'], function($v){ return $v['time'] > strtotime('today'); }));
$monthlyVisits = count(array_filter($data['visits'], function($v){ return $v['time'] > strtotime('-30 days'); }));
$dailyRevenue = count(array_filter($data['payments'], function($p){ return $p['time'] > strtotime('today'); })) * 69;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Neon Stats Mobile</title>
    <style>
        :root { --neon: #00ff88; --bg: #000; --card: #111; --blue: #00d4ff; }
        * { box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
        
        body { font-family: 'Segoe UI', Roboto, sans-serif; background: var(--bg); color: white; margin: 0; padding: 15px; padding-bottom: 50px; }
        
        .app-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding: 5px; }
        .app-header h1 { font-size: 20px; margin: 0; color: var(--neon); letter-spacing: 1px; }

        /* Mobile Stats Grid */
        .mobile-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 25px; }
        .m-card { background: var(--card); padding: 15px; border-radius: 18px; border: 1px solid #222; text-align: center; }
        .m-card span { display: block; font-size: 10px; color: #666; text-transform: uppercase; margin-bottom: 5px; }
        .m-card b { font-size: 20px; color: #fff; }
        .m-card.active { border-color: var(--neon); box-shadow: 0 0 10px rgba(0,255,136,0.1); }

        /* List Sections */
        .section-title { font-size: 14px; font-weight: bold; margin: 20px 0 12px 5px; color: var(--blue); display: flex; justify-content: space-between; }
        
        .list-container { background: var(--card); border-radius: 20px; overflow: hidden; border: 1px solid #1a1a1a; }
        
        .list-item { display: flex; align-items: center; padding: 15px; border-bottom: 1px solid #1a1a1a; }
        .list-item:last-child { border-bottom: none; }
        
        .icon-circle { width: 40px; height: 40px; border-radius: 50%; background: #1a1a1a; display: flex; align-items: center; justify-content: center; margin-right: 12px; border: 1px solid #333; }
        
        .item-info { flex: 1; }
        .item-info b { display: block; font-size: 13px; margin-bottom: 2px; }
        .item-info small { color: #555; font-size: 11px; }
        
        .item-side { text-align: right; }
        .item-side .amt { color: var(--neon); font-weight: bold; font-size: 14px; }
        .item-side .time { display: block; font-size: 10px; color: #444; margin-top: 3px; }

        .ip-text { font-family: monospace; color: var(--blue); font-size: 12px; }

        /* Refresh Button (Floating) */
        .refresh-btn { position: fixed; bottom: 20px; right: 20px; background: var(--neon); color: black; width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 5px 15px rgba(0,255,136,0.4); border: none; font-size: 20px; cursor: pointer; }
    </style>
</head>
<body>

    <div class="app-header">
        <h1>ITACHI DASHBOARD </h1>
        <div style="font-size: 10px; color: #444;">Live Analytics</div>
    </div>

    <div class="mobile-grid">
        <div class="m-card active">
            <span>Total Visits</span>
            <b><?php echo $totalVisits; ?></b>
        </div>
        <div class="m-card">
            <span>Daily Traffic</span>
            <b><?php echo $dailyVisits; ?></b>
        </div>
        <div class="m-card">
            <span>Sales</span>
            <b><?php echo $totalPayments; ?></b>
        </div>
        <div class="m-card">
            <span>Daily INR</span>
            <b style="color: var(--neon);">₹<?php echo $dailyRevenue; ?></b>
        </div>
    </div>

    <div class="section-title">
        <span>RECENT PAYMENTS</span>
        <span style="font-size: 10px; color: #444;">TOTAL: <?php echo $totalPayments; ?></span>
    </div>
    <div class="list-container">
        <?php if(empty($data['payments'])): ?>
            <div style="padding: 20px; text-align: center; color: #444; font-size: 12px;">No payments yet</div>
        <?php else: ?>
            <?php foreach(array_slice(array_reverse($data['payments']), 0, 10) as $p): ?>
            <div class="list-item">
                <div class="icon-circle" style="color: var(--neon);">₹</div>
                <div class="item-info">
                    <b><?php echo $p['user']; ?></b>
                    <small>UTR: <?php echo substr($p['utr'], 0, 4) . '****' . substr($p['utr'], -4); ?></small>
                </div>
                <div class="item-side">
                    <div class="amt">+₹69</div>
                    <span class="time"><?php echo time_ago($p['time']); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="section-title">
        <span>LIVE VISITORS</span>
    </div>
    <div class="list-container">
        <?php foreach(array_slice(array_reverse($data['visits']), 0, 8) as $v): ?>
        <div class="list-item">
            <div class="icon-circle">👤</div>
            <div class="item-info">
                <span class="ip-text"><?php echo $v['ip']; ?></span>
                <small>Browsing payment page</small>
            </div>
            <div class="item-side">
                <span class="time"><?php echo time_ago($v['time']); ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <button class="refresh-btn" onclick="location.reload()">↻</button>

</body>
</html>
